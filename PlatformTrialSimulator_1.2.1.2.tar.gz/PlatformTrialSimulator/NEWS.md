# PlatformTrialSimulator 1.2.1.1

## Release Date 04/17/2019

## Major Features

Added use of package website build with pkgdown.   

Here is some more stuff.   

# Version 1.2.1.0
Features nothing

