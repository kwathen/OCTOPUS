
R CMD INSTALL PlatformTrialSimulator_1.2.0.4.tar.gz

library( PlatformTrialSimulator)
library(ggplot2)

# lSimResPOC <- SimulateAccrual( nQtyReps, 1, nMaxQtyPats, dDelayBetweenTrialsPOC, 
#                                vPatsPerMonthPerSite1, vQtyOfSitesPOC1, vPatsPerMonthPerSite1, vQtyOfSitesPOC1, dDelayToStartPOC )

SimulateAccrual

#2 separate study
lSimResPOC <- SimulateAccrual( 100, 60, 6,c(0.1,0.3,0.45, 0.5),c(5,10,15,20,25,35), c(0.1,0.3,0.45, 0.5),c(5,10,15,20,25,35), 1 )

#For Platform
lSimResPlat<- SimulateAccrual( 100, 60, 3,c(0.1,0.3,0.45, 0.5),c(3,8,15,35,50,70), c(0.1,0.3,0.45, 0.5),c(7.5, 15, 23,30, 37.5, 70), 1 )


# setwd("C:/Users/wtalloen/JNJ/TMEDS_IDV - Documents/_projects/workstreams/platformProtocol/simulations/recruitment_Kyle")
# load("lSimResPlat.rda")
# load("lSimResPOC.rda")

# length(lSimResPlat$vStartPerMonthMean)

n <- 50
prepStart <- -6
# plotData <- data.frame(nSubjects = c(lSimResPlat$vStartPerMonthMean[c(1:9, 13:(n+3))], lSimResPOC$vStartPerMonthMean[1:n]),
#                        Months = c(c(1:n), c(1:n)+prepStart), Type = c(rep("One platform with two ISAs", n), rep("Two separate studies", n)))

#--------------------------------------------------------------------------------
# Two ISAs in platform
#--------------------------------------------------------------------------------

##############
# Without CI #
##############

plotData <- data.frame(nSubjects = c(lSimResPlat$vStartPerMonthMean[c(1:n)], lSimResPOC$vStartPerMonthMean[1:n]),
                       Months = c(c(1:n), c(1:n)), Type = c(rep("One platform with two ISAs", n), rep("Two separate studies", n)))


p <- ggplot(data=plotData, aes(x = Months, y = nSubjects, color = Type)) +
  # geom_line(size = 1) +
  geom_smooth(size = 1, span = 0.2, se = FALSE) +
  scale_color_manual(values = c("blue","green3")) + # scale_color_brewer(palette="Set1") +
  ylab("Number of subjects recruited") +
  xlim(c(0,25)) +
  theme_bw() +
  theme(legend.position = c(0.025, 0.925), 
        legend.justification = c(0, 1),
        legend.background = element_rect(colour = "black"), legend.title=element_blank())
  
p

ggsave("./recruitment.jpeg", p, width =7, height = 5)


###########
# With CI #
###########

plotData <- data.frame(nSubjects = c(lSimResPlat$vStartPerMonthMean[c(1:n)], lSimResPOC$vStartPerMonthMean[1:n]),
                       nSubjectsLower = c(lSimResPlat$vLower[c(1:n)], lSimResPOC$vLower[1:n]),
                       nSubjectsUpper = c(lSimResPlat$vUpper[c(1:n)], lSimResPOC$vUpper[1:n]),
                       Months = c(c(1:n), c(1:n)), Type = c(rep("One platform with two ISAs", n), rep("Two separate studies", n)))


p <- ggplot(data=plotData, aes(x = Months, y = nSubjects, color = Type)) +
  geom_ribbon(aes(ymin = nSubjectsLower, ymax = nSubjectsUpper, fill = Type), alpha = 0.3) +
  geom_line(size = 1) +
  # geom_smooth(size = 1, span = 0.2, se = FALSE) +
  scale_color_manual(values = c("blue","green3")) + # scale_color_brewer(palette="Set1") +
  scale_fill_manual(values = c("blue","green3")) + # scale_color_brewer(palette="Set1") +
  ylab("Number of subjects recruited") +
  xlim(c(0,25)) +
  theme_bw() +
  theme(legend.position = c(0.025, 0.925), 
        legend.justification = c(0, 1),
        legend.background = element_rect(colour = "black"), legend.title=element_blank())

p

ggsave("./recruitment.jpeg", p, width =7, height = 5)

#--------------------------------------------------------------------------------
# Two seperate studies
#--------------------------------------------------------------------------------

p <- ggplot(data=plotData[plotData$Type == "Two separate studies",], aes(x = Months, y = nSubjects, color = Type)) +
  # geom_line(size = 1) +
  geom_smooth(size = 1, span = 0.2, se = FALSE) +
  scale_color_manual(values = c("green3")) + # scale_color_brewer(palette="Set1") +
  ylab("Number of subjects recruited") +
  xlim(c(0,25)) +
  theme_bw() +
  theme(legend.position = c(0.025, 0.925), 
        legend.justification = c(0, 1),
        legend.background = element_rect(colour = "black"), legend.title=element_blank())

p

ggsave("./recruitment_2sepStudies.jpeg", p, width =7, height = 5)

