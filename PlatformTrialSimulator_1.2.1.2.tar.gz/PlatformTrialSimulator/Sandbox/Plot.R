mRec <- read.table( "all.csv", header=TRUE, sep=",")


dfRec <- data.frame( mRec )
dfRec$TimeBin <- round( dfRec$StartTime,1)
df <- do.call( rbind, tapply( dfRec$PatientNumber, dfRec$TimeBin , quantile, c(0.025, 0.5,0.975)))

plot( dfRec$StartTime, dfRec$PatientNumber, type='n')
lines( as.numeric(row.names(df)), df[,2] )
lines( as.numeric(row.names(df)), df[,1], lty=2 )
lines( as.numeric(row.names(df)), df[,3], lty=2 )


plot( dfRec$StartTime, dfRec$PatientNumber, type='n')
i<-1
for( i in 1:10 )
{

    vSub<- dfRec$GridIndex == i
    lines( dfRec$StartTime[vSub], dfRec$PatientNumber[vSub] )
    i=i+1

}


lines( lowess(dfRec$StartTime,dfRec$PatientNumber, f=.1 ), col=2, lwd=4)



p <- ggplot(data=dfRec, aes(x = StartTime, y = PatientNumber))  +
    geom_smooth(size = 1, span = 0.1, se = TRUE) +
    scale_color_manual(values = c("blue","green3")) + # scale_color_brewer(palette="Set1") +
    ylab("Number of subjects recruited") +
    xlim(c(0,20)) +
    theme_bw() +
    theme(legend.position = c(0.025, 0.925),
          legend.justification = c(0, 1),
          legend.background = element_rect(colour = "black"), legend.title=element_blank())

p
