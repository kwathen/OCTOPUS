rm out/*.*
rm log/*.*
rm ISAOut1/*.*

