
body <- dashboardBody(
    tabsetPanel(id="inTabset",
        tabPanel("Design Input",
                 fluidPage(
                     fluidRow( column(width=12,box( width="400px", title = "Common Input",
                                           numericInput( "nQtyReps", "Number of Virtual Trials: ", 100, step = 100),
                                           numericInput( "nMaxQtyPats", "Number of patients in POC/ISA: ", 100, step = 10),
                                           textInput( "vPatsPerMonthPerSite1", "Enter the number of patients enrolled per month per site ( , separated for a ramp-up)", value="0.1,0.3,0.45, 0.5" )
                     ) )),
                     fluidRow( column( width=6, box( width="400px", title = "2 POCs",
                                             numericInput( "dDelayToStartPOC", "Delay (in months) to start POC: ", 6,1 ),
                                             numericInput( "dDelayBetweenTrialsPOC", "Delay (in months) between POC Trials: ", 3,1 ),
                                             textInput( "vQtySitesPOC", "Enter the number of sites open in POC each month ( , separated)", value="5,10,15,20,25,35" )
                     ))
                     , column(width=6,
                     box( width="400px", title = "Platform Trial - 2 ISAs",
                          numericInput( "dDelayToStartPlat", "Delay (in months) to start platform: ", 6,1 ),
                          numericInput( "dDelayBetweenTrialsPlat", "Delay (in months) between ISAs: ", 1,1 ),
                          textInput("vQtySitesPlat1", "Enter the number of sites open in platform for ISA1, each month ( , separated)", value = "3,8,15,35,50,70"),
                          textInput("vQtySitesPlat2", "Enter the number of sites open in platform for ISA2, each month ( , separated)", value = "7.5, 15, 23,30, 37.5, 70")

                     ))
                 ), bsButton( "btnGeneratePlot", label="Generate Plot", style="success", block=F, size="large")
        ), value="inputPanel"),
        tabPanel("Recruitment Plots", value="plotPanel",
                 plotOutput("ctrlPlotRecruitment", height="400px")
        )
    )
)

