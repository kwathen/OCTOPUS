## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ---- eval = FALSE-------------------------------------------------------
#  library( PlatformTrialSimulator )
#  PlatformTrialSimulator::RunExample( "CompareRecruitment" )

