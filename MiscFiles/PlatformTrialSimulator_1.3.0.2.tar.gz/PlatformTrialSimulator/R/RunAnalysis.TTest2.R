RunAnalysis.TTest2 <- function( cAnalysis, lDataAna,  nISAAnalysisIndx, bIsFinalISAAnalysis, cRandomizer )
{
    
    
    lCI      <- GetCILimits(  cAnalysis, nISAAnalysisIndx, bIsFinalISAAnalysis )
    dLowerCI <- lCI$dLowerCI
    dUpperCI <- lCI$dUpperCI
    if( dLowerCI  == 1 - dUpperCI )  #Symmetrical CI so only need to do the test once to get the desired CI
    {
        dCILevel <- dUpperCI - dLowerCI
        
        
        lTTest  <- t.test(lDataAna$vOut ~ as.factor(lDataAna$vTrt), alternative = c("two.sided"),mu = 0, exact = NULL, correct = TRUE,  conf.int = TRUE, conf.level = dCILevel)
        Means   <- lTTest["estimate"]$estimate[[1]] - lTTest["estimate"]$estimate[[2]] #pbo- trt
        dLower  <- lTTest["conf.int"]$conf.int[[1]]
        dUpper  <- lTTest["conf.int"]$conf.int[[2]]
    }
    else
    {
        #The desired CI is not symmetrical so we need to do the test twice
        
        #Get the CI for the Lower Limit
        dCILevel <- 1 - 2*dLowerCI
        lTTest  <- t.test(lDataAna$vOut ~ as.factor(lDataAna$vTrt), alternative = c("two.sided"),mu = 0, exact = NULL, correct = TRUE,  conf.int = TRUE, conf.level = dCILevel)
        Means   <- lTTest["estimate"]$estimate[[1]] - lTTest["estimate"]$estimate[[2]] #pbo- trt
        dLower  <- lTTest["conf.int"]$conf.int[[1]]
        
        
        dCILevel <- 1 - 2*(1 - dUpperCI)
        lTTest  <- t.test(lDataAna$vOut ~ as.factor(lDataAna$vTrt), alternative = c("two.sided"),mu = 0, exact = NULL, correct = TRUE,  conf.int = TRUE, conf.level = dCILevel)
        dUpper  <- lTTest["conf.int"]$conf.int[[2]]
        
    }
    
    lRet <- MakeDecisionBasedOnCI( dLower, dUpper, cAnalysis )
    lRet$cRandomizer <- cRandomizer
    
    return( lRet )
    
}