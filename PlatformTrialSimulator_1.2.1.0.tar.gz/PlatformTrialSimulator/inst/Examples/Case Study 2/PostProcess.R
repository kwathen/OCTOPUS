##### COPYRIGHT #############################################################################################################
#
# Copyright (C) 2018 JANSSEN RESEARCH & DEVELOPMENT, LLC
# This package is governed by the JRD Platform Trial Simulation License, which is the
# GNU General Public License V3 with additional terms. The precise license terms are located in the files
# LICENSE and GPL.
#
#############################################################################################################################.

#############################################################################################################################.
#   This file will post process the results from the simulation
#   The the PostProcess functions are used for a calculating summary statistics on
#   simulations that are run on the grid
#   This functions are not generic (have not had time for this) and hence are based on
#   number of ISAs in the simulation
#############################################################################################################################.

PostProcess1ISA  <- function( mSims, nScen )
{

    mSimsTmp <- mSims[ mSims$iScen == nScen, ]
    print(paste( "Scen ", nScen, " Qty Reps ", nrow(mSimsTmp)))
    dAvePlacISA1  <- mean( mSimsTmp$ISA1Trt1 )
    dAveTrtISA1   <- mean( mSimsTmp$ISA1Trt2 )


    dAveN     <- dAvePlacISA1 + dAveTrtISA1

    #ISA 1 status
    vISAStatus <- c(mSimsTmp$ISA1Status, 3:7)
    vTableStatus <- table( vISAStatus ) - 1  #Subtracting 1 because the 3:7 added all possible status options
    vTableStatus <- vTableStatus/nrow( mSimsTmp )

    dProbClosedIAISA1 <- sum(vTableStatus[1:2])
    dProbFAISA1       <- sum( vTableStatus[3:5])
    dProbGoISA1       <- vTableStatus[1]+vTableStatus[3]
    dProbNoGoISA1     <- vTableStatus[2]+vTableStatus[4]
    #   0 = ISA not open;
    #   1 = ISA open,
    #   2 = met max enrolment,
    #   3 = Closed with a Go before FA,
    #   4 = Closed - No Go before FA
    #   5 = closed - Go at the FA
    #   6 = Closed - No Go at the FA
    #   7 = Closed - Pause at the FA


    return( c( dAvePlacISA1=dAvePlacISA1,
                  dAveTrtISA1 = dAveTrtISA1,
                  dProbClosedIAISA1 = dProbClosedIAISA1,
                  dProbFAISA1 = dProbFAISA1,
                  dProbGoISA1 = dProbGoISA1,
                  dProbNoGoISA1 = dProbNoGoISA1))
}


library( PlatformTrialSimulatorPublic)


########################################################################
#   Read in the data from the simulation with borrowing
#   make sure your working directory is the same as this file or
#   add the directory to the string below
########################################################################

load( "sims.RData")

#strMain <- "allmain.csv"
#vStrISA <- c("allisa1.csv", "allisa2.csv","allisa3.csv","allisa3.csv")
#vISANumber <- c(1,2,3,4)

#simsAll <- BuildResultsDataSet( strMain, vStrISA, vISANumber )  #This is a fct in the PTS Package

#write.table(simsAll, "combined.csv", quote=FALSE, sep="," , row.names=FALSE)
#mSimsTmp <- simsAll[ mSims$iScen == nScen, ]
#nrow( simsAll)

vScen <- unique(simsAll$iScen)

vRes <- c( 1, PostProcess1ISA( simsAll, 1))
for( iScen in 2:length(vScen) )
{
    vRes <- rbind( vRes, c(iScen, PostProcess1ISA( simsAll, iScen)))
}

colnames( vRes )<-c( "Scen", "Ave N Plac", "Ave N Trt", "Pr(Closed IA)", "Pr( FA )", "Pr( Go )", "Pr( No Go )")
vX <- c(0,0.1,0.2,0.3,0.4,0.5)
plot( vX, vRes[,"Pr( Go )"], type='l', xlab="% Difference", ylab="Probability")
lines( vX, vRes[,"Pr( Go )"], lwd=2, col="green")
lines( vX, vRes[,"Pr( No Go )"], lwd=2, col="red")
lines( vX, 1.0-vRes[,"Pr( Go )"]-vRes[,"Pr( No Go )"], lwd=2, col="yellow")


abline( v= seq( 0.0, .5, .05), h=seq( 0,1, .1), lty=2, col=8)



